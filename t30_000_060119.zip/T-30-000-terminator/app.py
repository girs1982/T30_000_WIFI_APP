#!/usr/bin/env python
from importlib import import_module
import os
from flask import Flask, render_template, Response
from RPi import GPIO
from pizypwm import *
from flask import request
import json
# import camera driver
if os.environ.get('CAMERA'):
    Camera = import_module('camera_' + os.environ['CAMERA']).Camera
else:
    from camera import Camera

# Raspberry Pi camera module (requires picamera package)
# from camera_pi import Camera
gazul = 0
naklonv = 10
#gaz = PiZyPwm(100, 18, GPIO.BCM)
#gaz.start(gazul)

naklonzu = PiZyPwm(100, 20, GPIO.BCM)
naklonzu.start(naklonv)
pitchzu = PiZyPwm(100, 19, GPIO.BCM)
pitchzu.start(naklonv)
rotatezu = PiZyPwm(100, 21, GPIO.BCM)
rotatezu.start(naklonv)






gus0 = PiZyPwm(100, 17, GPIO.BCM)
gus1 = PiZyPwm(100, 22, GPIO.BCM)
gus2 = PiZyPwm(100, 27, GPIO.BCM)
gus3 = PiZyPwm(100, 23, GPIO.BCM)


gus0.start(0)
gus1.start(0)
gus2.start(0)
gus3.start(0)

class PWM:
    def __init__( self, pin ):
        self.pin = pin

    def set( self, value ):
        cmd = 'echo "%d=%.2f" > /dev/pi-blaster' % ( self.pin, value )
        os.system(cmd)




app = Flask(__name__, static_folder='static', static_url_path='/static')


@app.route('/')
def index():
    """Video streaming home page."""
    return render_template('index.html')


def gen(camera):
    """Video streaming generator function."""
    while True:
        frame = camera.get_frame()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')


@app.route('/video_feed')
def video_feed():
    """Video streaming route. Put this in the src attribute of an img tag."""
    return Response(gen(Camera()),
                    mimetype='multipart/x-mixed-replace; boundary=frame')



@app.route('/vpravo',methods=['GET', 'POST'])
def vpravo():
     nil = request.args['vpravo']
     fl = int(nil)  
 #    gazul = fl
 #    gaz.changeDutyCycle(gazul)
#     gazuli = request.args.get('vpravo')
#     gus0 = PiZyPwm(100, 17, GPIO.BCM)
 #    gus1 = PiZyPwm(100, 22, GPIO.BCM)
  #   gus2 = PiZyPwm(100, 27, GPIO.BCM)
   #  gus3 = PiZyPwm(100, 23, GPIO.BCM)
     gus0.changeDutyCycle(gazul)
     gus1.changeDutyCycle(0)
     gus2.changeDutyCycle(0)
     gus3.changeDutyCycle(gazul)
     print request.args['vpravo']
     print nil
     return 'VPRAVO'




@app.route('/vpravo1',methods=['GET', 'POST'])
def vpravo1():
     nil = request.args['vpravo']
     fl = int(nil)
  #   gazul = fl
   #  gaz.changeDutyCycle(gazul)
#     gazuli = request.args.get('vpravo')
#     gus0 = PiZyPwm(100, 17, GPIO.BCM)
 #    gus1 = PiZyPwm(100, 22, GPIO.BCM)
  #   gus2 = PiZyPwm(100, 27, GPIO.BCM)
   #  gus3 = PiZyPwm(100, 23, GPIO.BCM)
     gus0.changeDutyCycle(gazul)
     gus1.changeDutyCycle(0)
     gus2.changeDutyCycle(0)
     gus3.changeDutyCycle(gazul)
     time.sleep(0.1)
     gus0.changeDutyCycle(0)
     gus1.changeDutyCycle(0)
     gus2.changeDutyCycle(0)
     gus3.changeDutyCycle(0)


     print request.args['vpravo']
     print nil
     return 'VPRAVO_SMALL'+str(nil)





     
@app.route('/vlevo',methods=['GET', 'POST'])
def vlevo():

     nil = request.args['vlevo']
     fl = int(nil)
    # gazul = fl
    # gaz.changeDutyCycle(gazul)


     gus0.changeDutyCycle(0)
     gus1.changeDutyCycle(gazul)
     gus2.changeDutyCycle(gazul)
     gus3.changeDutyCycle(0)
     return 'VLEVO'





@app.route('/vlevo1',methods=['GET', 'POST'])
def vlevo1():

     nil = request.args['vlevo']
     fl = int(nil)
    # gazul = fl
    # gaz.changeDutyCycle(gazul)


     gus0.changeDutyCycle(0)
     gus1.changeDutyCycle(gazul)
     gus2.changeDutyCycle(gazul)
     gus3.changeDutyCycle(0)
     time.sleep(0.1)
     gus0.changeDutyCycle(0)
     gus1.changeDutyCycle(0)
     gus2.changeDutyCycle(0)
     gus3.changeDutyCycle(0)
 

     return 'VLEVO_SMALL'




@app.route('/vverh',methods=['GET', 'POST'])
def vverh():

     nil = request.args['vverh']
     fl = int(nil)
    # gazul = fl
    # gaz.changeDutyCycle(gazul)

     
     gus0.changeDutyCycle(gazul)
     gus1.changeDutyCycle(0)
     gus2.changeDutyCycle(gazul)
     gus3.changeDutyCycle(0)



     return 'VVERH'

@app.route('/vniz',methods=['GET', 'POST'])
def vniz():



     nil = request.args['vniz']
     fl = int(nil)
    # gazul = fl
    # gaz.changeDutyCycle(gazul)


     nil = request.args['vniz']
     fl = int(nil)
    # gazul = fl
    # gaz.changeDutyCycle(gazul)


     gus0.changeDutyCycle(0)
     gus1.changeDutyCycle(gazul)
     gus2.changeDutyCycle(0)
     gus3.changeDutyCycle(gazul)
     return 'VNIZ'









@app.route('/fire',methods=['GET', 'POST'])
def fire():



   #  nil = request.args['fire']
   #  fl = float(nil)
     return 'FIRE'






@app.route('/stop',methods=['GET', 'POST'])
def stop():

     gus0.changeDutyCycle(0)
     gus1.changeDutyCycle(0)
     gus2.changeDutyCycle(0)
     gus3.changeDutyCycle(0)


     return 'STOP'


@app.route('/gazd',methods=['GET', 'POST'])
def gazd():

     gazdv =  request.args['gazd']
     g = float(gazdv)
#     gaz.changeDutyCycle(g)
     blasgaz = PWM(18)
     blasgaz.set(g)
     print g
     return 'GAZD'


@app.route('/naklon',methods=['GET', 'POST'])
def naklon():

     gazdv =  request.args['naklon']
     g = int(gazdv)
     naklonzu.changeDutyCycle(g)
     print g
     return 'NAKLON'
@app.route('/pitch',methods=['GET', 'POST'])
def pitch():

     gazdv =  request.args['pitch']
     g = int(gazdv)
     pitchzu.changeDutyCycle(g)
     print g
     return 'PITCH'
@app.route('/rotate',methods=['GET', 'POST'])
def rotate():

     rotate =  request.args['rotate']
     g = int(rotate)
     rotatezu.changeDutyCycle(g)
     print g
     return 'ROTATE'




if __name__ == '__main__':
    app.run(host='0.0.0.0', threaded=True)
