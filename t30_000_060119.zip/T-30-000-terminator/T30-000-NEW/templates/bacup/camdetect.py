﻿import cv2
from base_camera import BaseCamera

import numpy as np 

face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
eye_cascade = cv2.CascadeClassifier('haarcascade_eye.xml')


class Camera(BaseCamera):
    video_source = 0

    @staticmethod
    def set_video_source(source):
        Camera.video_source = source

    @staticmethod
    def frames():
        camera = cv2.VideoCapture(Camera.video_source)
        if not camera.isOpened():
            raise RuntimeError('Could not start camera.')

        while True:
            # read current frame
            _, img = camera.read()
            frame = img
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)
           # print(len(faces))
            for (x,y,w,h) in faces:
                  cv2.rectangle(frame,(x,y),(x+w,y+h),(255,0,0),2)
                  roi_gray = gray[y:y+h, x:x+w]
                  roi_color = frame[y:y+h, x:x+w]
                  eyes = eye_cascade.detectMultiScale(roi_gray)
                  for (ex,ey,ew,eh) in eyes:
                       cv2.rectangle(roi_color,(ex,ey),(ex+ew,ey+eh),(0,255,0),2)
            final_wide = 600
            r = float(final_wide) / frame.shape[1]
            dim = (final_wide, int(frame.shape[0] * r))
            resized = cv2.resize(frame, dim, interpolation = cv2.INTER_AREA)



            # encode as a jpeg image and return it
            yield cv2.imencode('.jpg', resized)[1].tobytes()



